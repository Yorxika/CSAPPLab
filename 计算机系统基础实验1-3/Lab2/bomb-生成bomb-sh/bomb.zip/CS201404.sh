./makebomb.pl -i 201214882 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201214882
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201214882
cd ../..
cp ./bombs/bomb201214882/bomb ./allbombs/CS201404/U201214882
cp ./bombs/bomb201214882/bomb.c ./allbombs/CS201404/U201214882
cp ./bombs/bomb201214882/ID ./allbombs/CS201404/U201214882
cp ./bombs/bomb201214882/README ./allbombs/CS201404/U201214882
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414648 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414648
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414648
cd ../..
cp ./bombs/bomb201414648/bomb ./allbombs/CS201404/U201414648
cp ./bombs/bomb201414648/bomb.c ./allbombs/CS201404/U201414648
cp ./bombs/bomb201414648/ID ./allbombs/CS201404/U201414648
cp ./bombs/bomb201414648/README ./allbombs/CS201404/U201414648
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414650 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414650
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414650
cd ../..
cp ./bombs/bomb201414650/bomb ./allbombs/CS201404/U201414650
cp ./bombs/bomb201414650/bomb.c ./allbombs/CS201404/U201414650
cp ./bombs/bomb201414650/ID ./allbombs/CS201404/U201414650
cp ./bombs/bomb201414650/README ./allbombs/CS201404/U201414650
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414651 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414651
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414651
cd ../..
cp ./bombs/bomb201414651/bomb ./allbombs/CS201404/U201414651
cp ./bombs/bomb201414651/bomb.c ./allbombs/CS201404/U201414651
cp ./bombs/bomb201414651/ID ./allbombs/CS201404/U201414651
cp ./bombs/bomb201414651/README ./allbombs/CS201404/U201414651
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414652 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414652
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414652
cd ../..
cp ./bombs/bomb201414652/bomb ./allbombs/CS201404/U201414652
cp ./bombs/bomb201414652/bomb.c ./allbombs/CS201404/U201414652
cp ./bombs/bomb201414652/ID ./allbombs/CS201404/U201414652
cp ./bombs/bomb201414652/README ./allbombs/CS201404/U201414652
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414653 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414653
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414653
cd ../..
cp ./bombs/bomb201414653/bomb ./allbombs/CS201404/U201414653
cp ./bombs/bomb201414653/bomb.c ./allbombs/CS201404/U201414653
cp ./bombs/bomb201414653/ID ./allbombs/CS201404/U201414653
cp ./bombs/bomb201414653/README ./allbombs/CS201404/U201414653
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414654 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414654
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414654
cd ../..
cp ./bombs/bomb201414654/bomb ./allbombs/CS201404/U201414654
cp ./bombs/bomb201414654/bomb.c ./allbombs/CS201404/U201414654
cp ./bombs/bomb201414654/ID ./allbombs/CS201404/U201414654
cp ./bombs/bomb201414654/README ./allbombs/CS201404/U201414654
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414655 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414655
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414655
cd ../..
cp ./bombs/bomb201414655/bomb ./allbombs/CS201404/U201414655
cp ./bombs/bomb201414655/bomb.c ./allbombs/CS201404/U201414655
cp ./bombs/bomb201414655/ID ./allbombs/CS201404/U201414655
cp ./bombs/bomb201414655/README ./allbombs/CS201404/U201414655
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414656 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414656
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414656
cd ../..
cp ./bombs/bomb201414656/bomb ./allbombs/CS201404/U201414656
cp ./bombs/bomb201414656/bomb.c ./allbombs/CS201404/U201414656
cp ./bombs/bomb201414656/ID ./allbombs/CS201404/U201414656
cp ./bombs/bomb201414656/README ./allbombs/CS201404/U201414656
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414657 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414657
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414657
cd ../..
cp ./bombs/bomb201414657/bomb ./allbombs/CS201404/U201414657
cp ./bombs/bomb201414657/bomb.c ./allbombs/CS201404/U201414657
cp ./bombs/bomb201414657/ID ./allbombs/CS201404/U201414657
cp ./bombs/bomb201414657/README ./allbombs/CS201404/U201414657
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414658 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414658
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414658
cd ../..
cp ./bombs/bomb201414658/bomb ./allbombs/CS201404/U201414658
cp ./bombs/bomb201414658/bomb.c ./allbombs/CS201404/U201414658
cp ./bombs/bomb201414658/ID ./allbombs/CS201404/U201414658
cp ./bombs/bomb201414658/README ./allbombs/CS201404/U201414658
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414659 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414659
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414659
cd ../..
cp ./bombs/bomb201414659/bomb ./allbombs/CS201404/U201414659
cp ./bombs/bomb201414659/bomb.c ./allbombs/CS201404/U201414659
cp ./bombs/bomb201414659/ID ./allbombs/CS201404/U201414659
cp ./bombs/bomb201414659/README ./allbombs/CS201404/U201414659
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414661 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414661
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414661
cd ../..
cp ./bombs/bomb201414661/bomb ./allbombs/CS201404/U201414661
cp ./bombs/bomb201414661/bomb.c ./allbombs/CS201404/U201414661
cp ./bombs/bomb201414661/ID ./allbombs/CS201404/U201414661
cp ./bombs/bomb201414661/README ./allbombs/CS201404/U201414661
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414662 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414662
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414662
cd ../..
cp ./bombs/bomb201414662/bomb ./allbombs/CS201404/U201414662
cp ./bombs/bomb201414662/bomb.c ./allbombs/CS201404/U201414662
cp ./bombs/bomb201414662/ID ./allbombs/CS201404/U201414662
cp ./bombs/bomb201414662/README ./allbombs/CS201404/U201414662
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414664 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414664
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414664
cd ../..
cp ./bombs/bomb201414664/bomb ./allbombs/CS201404/U201414664
cp ./bombs/bomb201414664/bomb.c ./allbombs/CS201404/U201414664
cp ./bombs/bomb201414664/ID ./allbombs/CS201404/U201414664
cp ./bombs/bomb201414664/README ./allbombs/CS201404/U201414664
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414665 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414665
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414665
cd ../..
cp ./bombs/bomb201414665/bomb ./allbombs/CS201404/U201414665
cp ./bombs/bomb201414665/bomb.c ./allbombs/CS201404/U201414665
cp ./bombs/bomb201414665/ID ./allbombs/CS201404/U201414665
cp ./bombs/bomb201414665/README ./allbombs/CS201404/U201414665
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414666 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414666
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414666
cd ../..
cp ./bombs/bomb201414666/bomb ./allbombs/CS201404/U201414666
cp ./bombs/bomb201414666/bomb.c ./allbombs/CS201404/U201414666
cp ./bombs/bomb201414666/ID ./allbombs/CS201404/U201414666
cp ./bombs/bomb201414666/README ./allbombs/CS201404/U201414666
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414667 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414667
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414667
cd ../..
cp ./bombs/bomb201414667/bomb ./allbombs/CS201404/U201414667
cp ./bombs/bomb201414667/bomb.c ./allbombs/CS201404/U201414667
cp ./bombs/bomb201414667/ID ./allbombs/CS201404/U201414667
cp ./bombs/bomb201414667/README ./allbombs/CS201404/U201414667
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414668 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414668
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414668
cd ../..
cp ./bombs/bomb201414668/bomb ./allbombs/CS201404/U201414668
cp ./bombs/bomb201414668/bomb.c ./allbombs/CS201404/U201414668
cp ./bombs/bomb201414668/ID ./allbombs/CS201404/U201414668
cp ./bombs/bomb201414668/README ./allbombs/CS201404/U201414668
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414669 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414669
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414669
cd ../..
cp ./bombs/bomb201414669/bomb ./allbombs/CS201404/U201414669
cp ./bombs/bomb201414669/bomb.c ./allbombs/CS201404/U201414669
cp ./bombs/bomb201414669/ID ./allbombs/CS201404/U201414669
cp ./bombs/bomb201414669/README ./allbombs/CS201404/U201414669
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414670 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414670
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414670
cd ../..
cp ./bombs/bomb201414670/bomb ./allbombs/CS201404/U201414670
cp ./bombs/bomb201414670/bomb.c ./allbombs/CS201404/U201414670
cp ./bombs/bomb201414670/ID ./allbombs/CS201404/U201414670
cp ./bombs/bomb201414670/README ./allbombs/CS201404/U201414670
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414671 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414671
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414671
cd ../..
cp ./bombs/bomb201414671/bomb ./allbombs/CS201404/U201414671
cp ./bombs/bomb201414671/bomb.c ./allbombs/CS201404/U201414671
cp ./bombs/bomb201414671/ID ./allbombs/CS201404/U201414671
cp ./bombs/bomb201414671/README ./allbombs/CS201404/U201414671
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414672 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414672
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414672
cd ../..
cp ./bombs/bomb201414672/bomb ./allbombs/CS201404/U201414672
cp ./bombs/bomb201414672/bomb.c ./allbombs/CS201404/U201414672
cp ./bombs/bomb201414672/ID ./allbombs/CS201404/U201414672
cp ./bombs/bomb201414672/README ./allbombs/CS201404/U201414672
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414673 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414673
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414673
cd ../..
cp ./bombs/bomb201414673/bomb ./allbombs/CS201404/U201414673
cp ./bombs/bomb201414673/bomb.c ./allbombs/CS201404/U201414673
cp ./bombs/bomb201414673/ID ./allbombs/CS201404/U201414673
cp ./bombs/bomb201414673/README ./allbombs/CS201404/U201414673
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414674 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414674
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414674
cd ../..
cp ./bombs/bomb201414674/bomb ./allbombs/CS201404/U201414674
cp ./bombs/bomb201414674/bomb.c ./allbombs/CS201404/U201414674
cp ./bombs/bomb201414674/ID ./allbombs/CS201404/U201414674
cp ./bombs/bomb201414674/README ./allbombs/CS201404/U201414674
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414675 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414675
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414675
cd ../..
cp ./bombs/bomb201414675/bomb ./allbombs/CS201404/U201414675
cp ./bombs/bomb201414675/bomb.c ./allbombs/CS201404/U201414675
cp ./bombs/bomb201414675/ID ./allbombs/CS201404/U201414675
cp ./bombs/bomb201414675/README ./allbombs/CS201404/U201414675
cd allbombs
zip -r CS201404.zip CS201404
cd ..

./makebomb.pl -i 201414676 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414676
cd allbombs
mkdir CS201404
cd CS201404
mkdir U201414676
cd ../..
cp ./bombs/bomb201414676/bomb ./allbombs/CS201404/U201414676
cp ./bombs/bomb201414676/bomb.c ./allbombs/CS201404/U201414676
cp ./bombs/bomb201414676/ID ./allbombs/CS201404/U201414676
cp ./bombs/bomb201414676/README ./allbombs/CS201404/U201414676
cd allbombs
zip -r CS201404.zip CS201404
cd ..

