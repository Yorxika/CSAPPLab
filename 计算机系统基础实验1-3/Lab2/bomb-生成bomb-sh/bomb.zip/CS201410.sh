./makebomb.pl -i 201414823 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414823
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414823
cd ../..
cp ./bombs/bomb201414823/bomb ./allbombs/CS201410/U201414823
cp ./bombs/bomb201414823/bomb.c ./allbombs/CS201410/U201414823
cp ./bombs/bomb201414823/ID ./allbombs/CS201410/U201414823
cp ./bombs/bomb201414823/README ./allbombs/CS201410/U201414823
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414825 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414825
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414825
cd ../..
cp ./bombs/bomb201414825/bomb ./allbombs/CS201410/U201414825
cp ./bombs/bomb201414825/bomb.c ./allbombs/CS201410/U201414825
cp ./bombs/bomb201414825/ID ./allbombs/CS201410/U201414825
cp ./bombs/bomb201414825/README ./allbombs/CS201410/U201414825
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414826 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414826
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414826
cd ../..
cp ./bombs/bomb201414826/bomb ./allbombs/CS201410/U201414826
cp ./bombs/bomb201414826/bomb.c ./allbombs/CS201410/U201414826
cp ./bombs/bomb201414826/ID ./allbombs/CS201410/U201414826
cp ./bombs/bomb201414826/README ./allbombs/CS201410/U201414826
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414827 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414827
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414827
cd ../..
cp ./bombs/bomb201414827/bomb ./allbombs/CS201410/U201414827
cp ./bombs/bomb201414827/bomb.c ./allbombs/CS201410/U201414827
cp ./bombs/bomb201414827/ID ./allbombs/CS201410/U201414827
cp ./bombs/bomb201414827/README ./allbombs/CS201410/U201414827
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414828 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414828
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414828
cd ../..
cp ./bombs/bomb201414828/bomb ./allbombs/CS201410/U201414828
cp ./bombs/bomb201414828/bomb.c ./allbombs/CS201410/U201414828
cp ./bombs/bomb201414828/ID ./allbombs/CS201410/U201414828
cp ./bombs/bomb201414828/README ./allbombs/CS201410/U201414828
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414829 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414829
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414829
cd ../..
cp ./bombs/bomb201414829/bomb ./allbombs/CS201410/U201414829
cp ./bombs/bomb201414829/bomb.c ./allbombs/CS201410/U201414829
cp ./bombs/bomb201414829/ID ./allbombs/CS201410/U201414829
cp ./bombs/bomb201414829/README ./allbombs/CS201410/U201414829
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414830 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414830
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414830
cd ../..
cp ./bombs/bomb201414830/bomb ./allbombs/CS201410/U201414830
cp ./bombs/bomb201414830/bomb.c ./allbombs/CS201410/U201414830
cp ./bombs/bomb201414830/ID ./allbombs/CS201410/U201414830
cp ./bombs/bomb201414830/README ./allbombs/CS201410/U201414830
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414831 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414831
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414831
cd ../..
cp ./bombs/bomb201414831/bomb ./allbombs/CS201410/U201414831
cp ./bombs/bomb201414831/bomb.c ./allbombs/CS201410/U201414831
cp ./bombs/bomb201414831/ID ./allbombs/CS201410/U201414831
cp ./bombs/bomb201414831/README ./allbombs/CS201410/U201414831
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414832 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414832
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414832
cd ../..
cp ./bombs/bomb201414832/bomb ./allbombs/CS201410/U201414832
cp ./bombs/bomb201414832/bomb.c ./allbombs/CS201410/U201414832
cp ./bombs/bomb201414832/ID ./allbombs/CS201410/U201414832
cp ./bombs/bomb201414832/README ./allbombs/CS201410/U201414832
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414833 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414833
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414833
cd ../..
cp ./bombs/bomb201414833/bomb ./allbombs/CS201410/U201414833
cp ./bombs/bomb201414833/bomb.c ./allbombs/CS201410/U201414833
cp ./bombs/bomb201414833/ID ./allbombs/CS201410/U201414833
cp ./bombs/bomb201414833/README ./allbombs/CS201410/U201414833
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414834 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414834
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414834
cd ../..
cp ./bombs/bomb201414834/bomb ./allbombs/CS201410/U201414834
cp ./bombs/bomb201414834/bomb.c ./allbombs/CS201410/U201414834
cp ./bombs/bomb201414834/ID ./allbombs/CS201410/U201414834
cp ./bombs/bomb201414834/README ./allbombs/CS201410/U201414834
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414835 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414835
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414835
cd ../..
cp ./bombs/bomb201414835/bomb ./allbombs/CS201410/U201414835
cp ./bombs/bomb201414835/bomb.c ./allbombs/CS201410/U201414835
cp ./bombs/bomb201414835/ID ./allbombs/CS201410/U201414835
cp ./bombs/bomb201414835/README ./allbombs/CS201410/U201414835
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414836 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414836
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414836
cd ../..
cp ./bombs/bomb201414836/bomb ./allbombs/CS201410/U201414836
cp ./bombs/bomb201414836/bomb.c ./allbombs/CS201410/U201414836
cp ./bombs/bomb201414836/ID ./allbombs/CS201410/U201414836
cp ./bombs/bomb201414836/README ./allbombs/CS201410/U201414836
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414837 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414837
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414837
cd ../..
cp ./bombs/bomb201414837/bomb ./allbombs/CS201410/U201414837
cp ./bombs/bomb201414837/bomb.c ./allbombs/CS201410/U201414837
cp ./bombs/bomb201414837/ID ./allbombs/CS201410/U201414837
cp ./bombs/bomb201414837/README ./allbombs/CS201410/U201414837
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414838 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414838
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414838
cd ../..
cp ./bombs/bomb201414838/bomb ./allbombs/CS201410/U201414838
cp ./bombs/bomb201414838/bomb.c ./allbombs/CS201410/U201414838
cp ./bombs/bomb201414838/ID ./allbombs/CS201410/U201414838
cp ./bombs/bomb201414838/README ./allbombs/CS201410/U201414838
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414839 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414839
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414839
cd ../..
cp ./bombs/bomb201414839/bomb ./allbombs/CS201410/U201414839
cp ./bombs/bomb201414839/bomb.c ./allbombs/CS201410/U201414839
cp ./bombs/bomb201414839/ID ./allbombs/CS201410/U201414839
cp ./bombs/bomb201414839/README ./allbombs/CS201410/U201414839
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414840 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414840
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414840
cd ../..
cp ./bombs/bomb201414840/bomb ./allbombs/CS201410/U201414840
cp ./bombs/bomb201414840/bomb.c ./allbombs/CS201410/U201414840
cp ./bombs/bomb201414840/ID ./allbombs/CS201410/U201414840
cp ./bombs/bomb201414840/README ./allbombs/CS201410/U201414840
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414841 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414841
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414841
cd ../..
cp ./bombs/bomb201414841/bomb ./allbombs/CS201410/U201414841
cp ./bombs/bomb201414841/bomb.c ./allbombs/CS201410/U201414841
cp ./bombs/bomb201414841/ID ./allbombs/CS201410/U201414841
cp ./bombs/bomb201414841/README ./allbombs/CS201410/U201414841
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414842 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414842
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414842
cd ../..
cp ./bombs/bomb201414842/bomb ./allbombs/CS201410/U201414842
cp ./bombs/bomb201414842/bomb.c ./allbombs/CS201410/U201414842
cp ./bombs/bomb201414842/ID ./allbombs/CS201410/U201414842
cp ./bombs/bomb201414842/README ./allbombs/CS201410/U201414842
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414843 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414843
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414843
cd ../..
cp ./bombs/bomb201414843/bomb ./allbombs/CS201410/U201414843
cp ./bombs/bomb201414843/bomb.c ./allbombs/CS201410/U201414843
cp ./bombs/bomb201414843/ID ./allbombs/CS201410/U201414843
cp ./bombs/bomb201414843/README ./allbombs/CS201410/U201414843
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414844 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414844
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414844
cd ../..
cp ./bombs/bomb201414844/bomb ./allbombs/CS201410/U201414844
cp ./bombs/bomb201414844/bomb.c ./allbombs/CS201410/U201414844
cp ./bombs/bomb201414844/ID ./allbombs/CS201410/U201414844
cp ./bombs/bomb201414844/README ./allbombs/CS201410/U201414844
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414845 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414845
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414845
cd ../..
cp ./bombs/bomb201414845/bomb ./allbombs/CS201410/U201414845
cp ./bombs/bomb201414845/bomb.c ./allbombs/CS201410/U201414845
cp ./bombs/bomb201414845/ID ./allbombs/CS201410/U201414845
cp ./bombs/bomb201414845/README ./allbombs/CS201410/U201414845
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414846 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414846
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414846
cd ../..
cp ./bombs/bomb201414846/bomb ./allbombs/CS201410/U201414846
cp ./bombs/bomb201414846/bomb.c ./allbombs/CS201410/U201414846
cp ./bombs/bomb201414846/ID ./allbombs/CS201410/U201414846
cp ./bombs/bomb201414846/README ./allbombs/CS201410/U201414846
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414847 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414847
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414847
cd ../..
cp ./bombs/bomb201414847/bomb ./allbombs/CS201410/U201414847
cp ./bombs/bomb201414847/bomb.c ./allbombs/CS201410/U201414847
cp ./bombs/bomb201414847/ID ./allbombs/CS201410/U201414847
cp ./bombs/bomb201414847/README ./allbombs/CS201410/U201414847
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414848 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414848
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414848
cd ../..
cp ./bombs/bomb201414848/bomb ./allbombs/CS201410/U201414848
cp ./bombs/bomb201414848/bomb.c ./allbombs/CS201410/U201414848
cp ./bombs/bomb201414848/ID ./allbombs/CS201410/U201414848
cp ./bombs/bomb201414848/README ./allbombs/CS201410/U201414848
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414850 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414850
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414850
cd ../..
cp ./bombs/bomb201414850/bomb ./allbombs/CS201410/U201414850
cp ./bombs/bomb201414850/bomb.c ./allbombs/CS201410/U201414850
cp ./bombs/bomb201414850/ID ./allbombs/CS201410/U201414850
cp ./bombs/bomb201414850/README ./allbombs/CS201410/U201414850
cd allbombs
zip -r CS201410.zip CS201410
cd ..

./makebomb.pl -i 201414851 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414851
cd allbombs
mkdir CS201410
cd CS201410
mkdir U201414851
cd ../..
cp ./bombs/bomb201414851/bomb ./allbombs/CS201410/U201414851
cp ./bombs/bomb201414851/bomb.c ./allbombs/CS201410/U201414851
cp ./bombs/bomb201414851/ID ./allbombs/CS201410/U201414851
cp ./bombs/bomb201414851/README ./allbombs/CS201410/U201414851
cd allbombs
zip -r CS201410.zip CS201410
cd ..

