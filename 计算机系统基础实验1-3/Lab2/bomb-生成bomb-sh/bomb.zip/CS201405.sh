./makebomb.pl -i 201414677 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414677
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414677
cd ../..
cp ./bombs/bomb201414677/bomb ./allbombs/CS201405/U201414677
cp ./bombs/bomb201414677/bomb.c ./allbombs/CS201405/U201414677
cp ./bombs/bomb201414677/ID ./allbombs/CS201405/U201414677
cp ./bombs/bomb201414677/README ./allbombs/CS201405/U201414677
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414678 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414678
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414678
cd ../..
cp ./bombs/bomb201414678/bomb ./allbombs/CS201405/U201414678
cp ./bombs/bomb201414678/bomb.c ./allbombs/CS201405/U201414678
cp ./bombs/bomb201414678/ID ./allbombs/CS201405/U201414678
cp ./bombs/bomb201414678/README ./allbombs/CS201405/U201414678
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414679 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414679
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414679
cd ../..
cp ./bombs/bomb201414679/bomb ./allbombs/CS201405/U201414679
cp ./bombs/bomb201414679/bomb.c ./allbombs/CS201405/U201414679
cp ./bombs/bomb201414679/ID ./allbombs/CS201405/U201414679
cp ./bombs/bomb201414679/README ./allbombs/CS201405/U201414679
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414680 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414680
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414680
cd ../..
cp ./bombs/bomb201414680/bomb ./allbombs/CS201405/U201414680
cp ./bombs/bomb201414680/bomb.c ./allbombs/CS201405/U201414680
cp ./bombs/bomb201414680/ID ./allbombs/CS201405/U201414680
cp ./bombs/bomb201414680/README ./allbombs/CS201405/U201414680
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414681 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414681
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414681
cd ../..
cp ./bombs/bomb201414681/bomb ./allbombs/CS201405/U201414681
cp ./bombs/bomb201414681/bomb.c ./allbombs/CS201405/U201414681
cp ./bombs/bomb201414681/ID ./allbombs/CS201405/U201414681
cp ./bombs/bomb201414681/README ./allbombs/CS201405/U201414681
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414682 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414682
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414682
cd ../..
cp ./bombs/bomb201414682/bomb ./allbombs/CS201405/U201414682
cp ./bombs/bomb201414682/bomb.c ./allbombs/CS201405/U201414682
cp ./bombs/bomb201414682/ID ./allbombs/CS201405/U201414682
cp ./bombs/bomb201414682/README ./allbombs/CS201405/U201414682
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414683 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414683
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414683
cd ../..
cp ./bombs/bomb201414683/bomb ./allbombs/CS201405/U201414683
cp ./bombs/bomb201414683/bomb.c ./allbombs/CS201405/U201414683
cp ./bombs/bomb201414683/ID ./allbombs/CS201405/U201414683
cp ./bombs/bomb201414683/README ./allbombs/CS201405/U201414683
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414684 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414684
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414684
cd ../..
cp ./bombs/bomb201414684/bomb ./allbombs/CS201405/U201414684
cp ./bombs/bomb201414684/bomb.c ./allbombs/CS201405/U201414684
cp ./bombs/bomb201414684/ID ./allbombs/CS201405/U201414684
cp ./bombs/bomb201414684/README ./allbombs/CS201405/U201414684
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414685 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414685
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414685
cd ../..
cp ./bombs/bomb201414685/bomb ./allbombs/CS201405/U201414685
cp ./bombs/bomb201414685/bomb.c ./allbombs/CS201405/U201414685
cp ./bombs/bomb201414685/ID ./allbombs/CS201405/U201414685
cp ./bombs/bomb201414685/README ./allbombs/CS201405/U201414685
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414688 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414688
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414688
cd ../..
cp ./bombs/bomb201414688/bomb ./allbombs/CS201405/U201414688
cp ./bombs/bomb201414688/bomb.c ./allbombs/CS201405/U201414688
cp ./bombs/bomb201414688/ID ./allbombs/CS201405/U201414688
cp ./bombs/bomb201414688/README ./allbombs/CS201405/U201414688
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414689 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414689
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414689
cd ../..
cp ./bombs/bomb201414689/bomb ./allbombs/CS201405/U201414689
cp ./bombs/bomb201414689/bomb.c ./allbombs/CS201405/U201414689
cp ./bombs/bomb201414689/ID ./allbombs/CS201405/U201414689
cp ./bombs/bomb201414689/README ./allbombs/CS201405/U201414689
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414690 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414690
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414690
cd ../..
cp ./bombs/bomb201414690/bomb ./allbombs/CS201405/U201414690
cp ./bombs/bomb201414690/bomb.c ./allbombs/CS201405/U201414690
cp ./bombs/bomb201414690/ID ./allbombs/CS201405/U201414690
cp ./bombs/bomb201414690/README ./allbombs/CS201405/U201414690
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414691 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414691
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414691
cd ../..
cp ./bombs/bomb201414691/bomb ./allbombs/CS201405/U201414691
cp ./bombs/bomb201414691/bomb.c ./allbombs/CS201405/U201414691
cp ./bombs/bomb201414691/ID ./allbombs/CS201405/U201414691
cp ./bombs/bomb201414691/README ./allbombs/CS201405/U201414691
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414692 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414692
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414692
cd ../..
cp ./bombs/bomb201414692/bomb ./allbombs/CS201405/U201414692
cp ./bombs/bomb201414692/bomb.c ./allbombs/CS201405/U201414692
cp ./bombs/bomb201414692/ID ./allbombs/CS201405/U201414692
cp ./bombs/bomb201414692/README ./allbombs/CS201405/U201414692
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414693 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414693
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414693
cd ../..
cp ./bombs/bomb201414693/bomb ./allbombs/CS201405/U201414693
cp ./bombs/bomb201414693/bomb.c ./allbombs/CS201405/U201414693
cp ./bombs/bomb201414693/ID ./allbombs/CS201405/U201414693
cp ./bombs/bomb201414693/README ./allbombs/CS201405/U201414693
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414694 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414694
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414694
cd ../..
cp ./bombs/bomb201414694/bomb ./allbombs/CS201405/U201414694
cp ./bombs/bomb201414694/bomb.c ./allbombs/CS201405/U201414694
cp ./bombs/bomb201414694/ID ./allbombs/CS201405/U201414694
cp ./bombs/bomb201414694/README ./allbombs/CS201405/U201414694
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414695 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414695
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414695
cd ../..
cp ./bombs/bomb201414695/bomb ./allbombs/CS201405/U201414695
cp ./bombs/bomb201414695/bomb.c ./allbombs/CS201405/U201414695
cp ./bombs/bomb201414695/ID ./allbombs/CS201405/U201414695
cp ./bombs/bomb201414695/README ./allbombs/CS201405/U201414695
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414697 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414697
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414697
cd ../..
cp ./bombs/bomb201414697/bomb ./allbombs/CS201405/U201414697
cp ./bombs/bomb201414697/bomb.c ./allbombs/CS201405/U201414697
cp ./bombs/bomb201414697/ID ./allbombs/CS201405/U201414697
cp ./bombs/bomb201414697/README ./allbombs/CS201405/U201414697
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414698 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414698
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414698
cd ../..
cp ./bombs/bomb201414698/bomb ./allbombs/CS201405/U201414698
cp ./bombs/bomb201414698/bomb.c ./allbombs/CS201405/U201414698
cp ./bombs/bomb201414698/ID ./allbombs/CS201405/U201414698
cp ./bombs/bomb201414698/README ./allbombs/CS201405/U201414698
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414699 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414699
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414699
cd ../..
cp ./bombs/bomb201414699/bomb ./allbombs/CS201405/U201414699
cp ./bombs/bomb201414699/bomb.c ./allbombs/CS201405/U201414699
cp ./bombs/bomb201414699/ID ./allbombs/CS201405/U201414699
cp ./bombs/bomb201414699/README ./allbombs/CS201405/U201414699
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414700 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414700
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414700
cd ../..
cp ./bombs/bomb201414700/bomb ./allbombs/CS201405/U201414700
cp ./bombs/bomb201414700/bomb.c ./allbombs/CS201405/U201414700
cp ./bombs/bomb201414700/ID ./allbombs/CS201405/U201414700
cp ./bombs/bomb201414700/README ./allbombs/CS201405/U201414700
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414701 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414701
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414701
cd ../..
cp ./bombs/bomb201414701/bomb ./allbombs/CS201405/U201414701
cp ./bombs/bomb201414701/bomb.c ./allbombs/CS201405/U201414701
cp ./bombs/bomb201414701/ID ./allbombs/CS201405/U201414701
cp ./bombs/bomb201414701/README ./allbombs/CS201405/U201414701
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414703 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414703
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414703
cd ../..
cp ./bombs/bomb201414703/bomb ./allbombs/CS201405/U201414703
cp ./bombs/bomb201414703/bomb.c ./allbombs/CS201405/U201414703
cp ./bombs/bomb201414703/ID ./allbombs/CS201405/U201414703
cp ./bombs/bomb201414703/README ./allbombs/CS201405/U201414703
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414704 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414704
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414704
cd ../..
cp ./bombs/bomb201414704/bomb ./allbombs/CS201405/U201414704
cp ./bombs/bomb201414704/bomb.c ./allbombs/CS201405/U201414704
cp ./bombs/bomb201414704/ID ./allbombs/CS201405/U201414704
cp ./bombs/bomb201414704/README ./allbombs/CS201405/U201414704
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414705 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414705
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414705
cd ../..
cp ./bombs/bomb201414705/bomb ./allbombs/CS201405/U201414705
cp ./bombs/bomb201414705/bomb.c ./allbombs/CS201405/U201414705
cp ./bombs/bomb201414705/ID ./allbombs/CS201405/U201414705
cp ./bombs/bomb201414705/README ./allbombs/CS201405/U201414705
cd allbombs
zip -r CS201405.zip CS201405
cd ..

./makebomb.pl -i 201414706 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414706
cd allbombs
mkdir CS201405
cd CS201405
mkdir U201414706
cd ../..
cp ./bombs/bomb201414706/bomb ./allbombs/CS201405/U201414706
cp ./bombs/bomb201414706/bomb.c ./allbombs/CS201405/U201414706
cp ./bombs/bomb201414706/ID ./allbombs/CS201405/U201414706
cp ./bombs/bomb201414706/README ./allbombs/CS201405/U201414706
cd allbombs
zip -r CS201405.zip CS201405
cd ..

