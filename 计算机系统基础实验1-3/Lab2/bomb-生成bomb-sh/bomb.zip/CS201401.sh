./makebomb.pl -i 201314793 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201314793
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201314793
cd ../..
cp ./bombs/bomb201314793/bomb ./allbombs/CS201401/U201314793
cp ./bombs/bomb201314793/bomb.c ./allbombs/CS201401/U201314793
cp ./bombs/bomb201314793/ID ./allbombs/CS201401/U201314793
cp ./bombs/bomb201314793/README ./allbombs/CS201401/U201314793
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414557 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414557
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414557
cd ../..
cp ./bombs/bomb201414557/bomb ./allbombs/CS201401/U201414557
cp ./bombs/bomb201414557/bomb.c ./allbombs/CS201401/U201414557
cp ./bombs/bomb201414557/ID ./allbombs/CS201401/U201414557
cp ./bombs/bomb201414557/README ./allbombs/CS201401/U201414557
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414558 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414558
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414558
cd ../..
cp ./bombs/bomb201414558/bomb ./allbombs/CS201401/U201414558
cp ./bombs/bomb201414558/bomb.c ./allbombs/CS201401/U201414558
cp ./bombs/bomb201414558/ID ./allbombs/CS201401/U201414558
cp ./bombs/bomb201414558/README ./allbombs/CS201401/U201414558
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414559 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414559
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414559
cd ../..
cp ./bombs/bomb201414559/bomb ./allbombs/CS201401/U201414559
cp ./bombs/bomb201414559/bomb.c ./allbombs/CS201401/U201414559
cp ./bombs/bomb201414559/ID ./allbombs/CS201401/U201414559
cp ./bombs/bomb201414559/README ./allbombs/CS201401/U201414559
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414560 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414560
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414560
cd ../..
cp ./bombs/bomb201414560/bomb ./allbombs/CS201401/U201414560
cp ./bombs/bomb201414560/bomb.c ./allbombs/CS201401/U201414560
cp ./bombs/bomb201414560/ID ./allbombs/CS201401/U201414560
cp ./bombs/bomb201414560/README ./allbombs/CS201401/U201414560
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414561 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414561
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414561
cd ../..
cp ./bombs/bomb201414561/bomb ./allbombs/CS201401/U201414561
cp ./bombs/bomb201414561/bomb.c ./allbombs/CS201401/U201414561
cp ./bombs/bomb201414561/ID ./allbombs/CS201401/U201414561
cp ./bombs/bomb201414561/README ./allbombs/CS201401/U201414561
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414562 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414562
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414562
cd ../..
cp ./bombs/bomb201414562/bomb ./allbombs/CS201401/U201414562
cp ./bombs/bomb201414562/bomb.c ./allbombs/CS201401/U201414562
cp ./bombs/bomb201414562/ID ./allbombs/CS201401/U201414562
cp ./bombs/bomb201414562/README ./allbombs/CS201401/U201414562
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414563 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414563
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414563
cd ../..
cp ./bombs/bomb201414563/bomb ./allbombs/CS201401/U201414563
cp ./bombs/bomb201414563/bomb.c ./allbombs/CS201401/U201414563
cp ./bombs/bomb201414563/ID ./allbombs/CS201401/U201414563
cp ./bombs/bomb201414563/README ./allbombs/CS201401/U201414563
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414564 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414564
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414564
cd ../..
cp ./bombs/bomb201414564/bomb ./allbombs/CS201401/U201414564
cp ./bombs/bomb201414564/bomb.c ./allbombs/CS201401/U201414564
cp ./bombs/bomb201414564/ID ./allbombs/CS201401/U201414564
cp ./bombs/bomb201414564/README ./allbombs/CS201401/U201414564
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414566 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414566
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414566
cd ../..
cp ./bombs/bomb201414566/bomb ./allbombs/CS201401/U201414566
cp ./bombs/bomb201414566/bomb.c ./allbombs/CS201401/U201414566
cp ./bombs/bomb201414566/ID ./allbombs/CS201401/U201414566
cp ./bombs/bomb201414566/README ./allbombs/CS201401/U201414566
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414567 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414567
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414567
cd ../..
cp ./bombs/bomb201414567/bomb ./allbombs/CS201401/U201414567
cp ./bombs/bomb201414567/bomb.c ./allbombs/CS201401/U201414567
cp ./bombs/bomb201414567/ID ./allbombs/CS201401/U201414567
cp ./bombs/bomb201414567/README ./allbombs/CS201401/U201414567
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414568 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414568
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414568
cd ../..
cp ./bombs/bomb201414568/bomb ./allbombs/CS201401/U201414568
cp ./bombs/bomb201414568/bomb.c ./allbombs/CS201401/U201414568
cp ./bombs/bomb201414568/ID ./allbombs/CS201401/U201414568
cp ./bombs/bomb201414568/README ./allbombs/CS201401/U201414568
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414569 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414569
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414569
cd ../..
cp ./bombs/bomb201414569/bomb ./allbombs/CS201401/U201414569
cp ./bombs/bomb201414569/bomb.c ./allbombs/CS201401/U201414569
cp ./bombs/bomb201414569/ID ./allbombs/CS201401/U201414569
cp ./bombs/bomb201414569/README ./allbombs/CS201401/U201414569
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414570 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414570
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414570
cd ../..
cp ./bombs/bomb201414570/bomb ./allbombs/CS201401/U201414570
cp ./bombs/bomb201414570/bomb.c ./allbombs/CS201401/U201414570
cp ./bombs/bomb201414570/ID ./allbombs/CS201401/U201414570
cp ./bombs/bomb201414570/README ./allbombs/CS201401/U201414570
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414571 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414571
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414571
cd ../..
cp ./bombs/bomb201414571/bomb ./allbombs/CS201401/U201414571
cp ./bombs/bomb201414571/bomb.c ./allbombs/CS201401/U201414571
cp ./bombs/bomb201414571/ID ./allbombs/CS201401/U201414571
cp ./bombs/bomb201414571/README ./allbombs/CS201401/U201414571
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414573 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414573
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414573
cd ../..
cp ./bombs/bomb201414573/bomb ./allbombs/CS201401/U201414573
cp ./bombs/bomb201414573/bomb.c ./allbombs/CS201401/U201414573
cp ./bombs/bomb201414573/ID ./allbombs/CS201401/U201414573
cp ./bombs/bomb201414573/README ./allbombs/CS201401/U201414573
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414574 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414574
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414574
cd ../..
cp ./bombs/bomb201414574/bomb ./allbombs/CS201401/U201414574
cp ./bombs/bomb201414574/bomb.c ./allbombs/CS201401/U201414574
cp ./bombs/bomb201414574/ID ./allbombs/CS201401/U201414574
cp ./bombs/bomb201414574/README ./allbombs/CS201401/U201414574
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414575 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414575
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414575
cd ../..
cp ./bombs/bomb201414575/bomb ./allbombs/CS201401/U201414575
cp ./bombs/bomb201414575/bomb.c ./allbombs/CS201401/U201414575
cp ./bombs/bomb201414575/ID ./allbombs/CS201401/U201414575
cp ./bombs/bomb201414575/README ./allbombs/CS201401/U201414575
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414576 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414576
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414576
cd ../..
cp ./bombs/bomb201414576/bomb ./allbombs/CS201401/U201414576
cp ./bombs/bomb201414576/bomb.c ./allbombs/CS201401/U201414576
cp ./bombs/bomb201414576/ID ./allbombs/CS201401/U201414576
cp ./bombs/bomb201414576/README ./allbombs/CS201401/U201414576
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414577 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414577
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414577
cd ../..
cp ./bombs/bomb201414577/bomb ./allbombs/CS201401/U201414577
cp ./bombs/bomb201414577/bomb.c ./allbombs/CS201401/U201414577
cp ./bombs/bomb201414577/ID ./allbombs/CS201401/U201414577
cp ./bombs/bomb201414577/README ./allbombs/CS201401/U201414577
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414578 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414578
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414578
cd ../..
cp ./bombs/bomb201414578/bomb ./allbombs/CS201401/U201414578
cp ./bombs/bomb201414578/bomb.c ./allbombs/CS201401/U201414578
cp ./bombs/bomb201414578/ID ./allbombs/CS201401/U201414578
cp ./bombs/bomb201414578/README ./allbombs/CS201401/U201414578
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414579 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414579
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414579
cd ../..
cp ./bombs/bomb201414579/bomb ./allbombs/CS201401/U201414579
cp ./bombs/bomb201414579/bomb.c ./allbombs/CS201401/U201414579
cp ./bombs/bomb201414579/ID ./allbombs/CS201401/U201414579
cp ./bombs/bomb201414579/README ./allbombs/CS201401/U201414579
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414580 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414580
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414580
cd ../..
cp ./bombs/bomb201414580/bomb ./allbombs/CS201401/U201414580
cp ./bombs/bomb201414580/bomb.c ./allbombs/CS201401/U201414580
cp ./bombs/bomb201414580/ID ./allbombs/CS201401/U201414580
cp ./bombs/bomb201414580/README ./allbombs/CS201401/U201414580
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414581 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414581
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414581
cd ../..
cp ./bombs/bomb201414581/bomb ./allbombs/CS201401/U201414581
cp ./bombs/bomb201414581/bomb.c ./allbombs/CS201401/U201414581
cp ./bombs/bomb201414581/ID ./allbombs/CS201401/U201414581
cp ./bombs/bomb201414581/README ./allbombs/CS201401/U201414581
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414582 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414582
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414582
cd ../..
cp ./bombs/bomb201414582/bomb ./allbombs/CS201401/U201414582
cp ./bombs/bomb201414582/bomb.c ./allbombs/CS201401/U201414582
cp ./bombs/bomb201414582/ID ./allbombs/CS201401/U201414582
cp ./bombs/bomb201414582/README ./allbombs/CS201401/U201414582
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414583 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414583
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414583
cd ../..
cp ./bombs/bomb201414583/bomb ./allbombs/CS201401/U201414583
cp ./bombs/bomb201414583/bomb.c ./allbombs/CS201401/U201414583
cp ./bombs/bomb201414583/ID ./allbombs/CS201401/U201414583
cp ./bombs/bomb201414583/README ./allbombs/CS201401/U201414583
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414584 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414584
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414584
cd ../..
cp ./bombs/bomb201414584/bomb ./allbombs/CS201401/U201414584
cp ./bombs/bomb201414584/bomb.c ./allbombs/CS201401/U201414584
cp ./bombs/bomb201414584/ID ./allbombs/CS201401/U201414584
cp ./bombs/bomb201414584/README ./allbombs/CS201401/U201414584
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414585 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414585
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414585
cd ../..
cp ./bombs/bomb201414585/bomb ./allbombs/CS201401/U201414585
cp ./bombs/bomb201414585/bomb.c ./allbombs/CS201401/U201414585
cp ./bombs/bomb201414585/ID ./allbombs/CS201401/U201414585
cp ./bombs/bomb201414585/README ./allbombs/CS201401/U201414585
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414586 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414586
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414586
cd ../..
cp ./bombs/bomb201414586/bomb ./allbombs/CS201401/U201414586
cp ./bombs/bomb201414586/bomb.c ./allbombs/CS201401/U201414586
cp ./bombs/bomb201414586/ID ./allbombs/CS201401/U201414586
cp ./bombs/bomb201414586/README ./allbombs/CS201401/U201414586
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414982 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414982
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414982
cd ../..
cp ./bombs/bomb201414982/bomb ./allbombs/CS201401/U201414982
cp ./bombs/bomb201414982/bomb.c ./allbombs/CS201401/U201414982
cp ./bombs/bomb201414982/ID ./allbombs/CS201401/U201414982
cp ./bombs/bomb201414982/README ./allbombs/CS201401/U201414982
cd allbombs
zip -r CS201401.zip CS201401
cd ..

