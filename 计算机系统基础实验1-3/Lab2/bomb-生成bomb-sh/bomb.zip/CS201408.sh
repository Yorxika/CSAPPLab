./makebomb.pl -i 201414766 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414766
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414766
cd ../..
cp ./bombs/bomb201414766/bomb ./allbombs/CS201408/U201414766
cp ./bombs/bomb201414766/bomb.c ./allbombs/CS201408/U201414766
cp ./bombs/bomb201414766/ID ./allbombs/CS201408/U201414766
cp ./bombs/bomb201414766/README ./allbombs/CS201408/U201414766
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414767 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414767
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414767
cd ../..
cp ./bombs/bomb201414767/bomb ./allbombs/CS201408/U201414767
cp ./bombs/bomb201414767/bomb.c ./allbombs/CS201408/U201414767
cp ./bombs/bomb201414767/ID ./allbombs/CS201408/U201414767
cp ./bombs/bomb201414767/README ./allbombs/CS201408/U201414767
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414768 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414768
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414768
cd ../..
cp ./bombs/bomb201414768/bomb ./allbombs/CS201408/U201414768
cp ./bombs/bomb201414768/bomb.c ./allbombs/CS201408/U201414768
cp ./bombs/bomb201414768/ID ./allbombs/CS201408/U201414768
cp ./bombs/bomb201414768/README ./allbombs/CS201408/U201414768
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414769 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414769
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414769
cd ../..
cp ./bombs/bomb201414769/bomb ./allbombs/CS201408/U201414769
cp ./bombs/bomb201414769/bomb.c ./allbombs/CS201408/U201414769
cp ./bombs/bomb201414769/ID ./allbombs/CS201408/U201414769
cp ./bombs/bomb201414769/README ./allbombs/CS201408/U201414769
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414770 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414770
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414770
cd ../..
cp ./bombs/bomb201414770/bomb ./allbombs/CS201408/U201414770
cp ./bombs/bomb201414770/bomb.c ./allbombs/CS201408/U201414770
cp ./bombs/bomb201414770/ID ./allbombs/CS201408/U201414770
cp ./bombs/bomb201414770/README ./allbombs/CS201408/U201414770
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414771 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414771
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414771
cd ../..
cp ./bombs/bomb201414771/bomb ./allbombs/CS201408/U201414771
cp ./bombs/bomb201414771/bomb.c ./allbombs/CS201408/U201414771
cp ./bombs/bomb201414771/ID ./allbombs/CS201408/U201414771
cp ./bombs/bomb201414771/README ./allbombs/CS201408/U201414771
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414772 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414772
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414772
cd ../..
cp ./bombs/bomb201414772/bomb ./allbombs/CS201408/U201414772
cp ./bombs/bomb201414772/bomb.c ./allbombs/CS201408/U201414772
cp ./bombs/bomb201414772/ID ./allbombs/CS201408/U201414772
cp ./bombs/bomb201414772/README ./allbombs/CS201408/U201414772
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414773 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414773
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414773
cd ../..
cp ./bombs/bomb201414773/bomb ./allbombs/CS201408/U201414773
cp ./bombs/bomb201414773/bomb.c ./allbombs/CS201408/U201414773
cp ./bombs/bomb201414773/ID ./allbombs/CS201408/U201414773
cp ./bombs/bomb201414773/README ./allbombs/CS201408/U201414773
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414774 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414774
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414774
cd ../..
cp ./bombs/bomb201414774/bomb ./allbombs/CS201408/U201414774
cp ./bombs/bomb201414774/bomb.c ./allbombs/CS201408/U201414774
cp ./bombs/bomb201414774/ID ./allbombs/CS201408/U201414774
cp ./bombs/bomb201414774/README ./allbombs/CS201408/U201414774
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414775 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414775
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414775
cd ../..
cp ./bombs/bomb201414775/bomb ./allbombs/CS201408/U201414775
cp ./bombs/bomb201414775/bomb.c ./allbombs/CS201408/U201414775
cp ./bombs/bomb201414775/ID ./allbombs/CS201408/U201414775
cp ./bombs/bomb201414775/README ./allbombs/CS201408/U201414775
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414776 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414776
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414776
cd ../..
cp ./bombs/bomb201414776/bomb ./allbombs/CS201408/U201414776
cp ./bombs/bomb201414776/bomb.c ./allbombs/CS201408/U201414776
cp ./bombs/bomb201414776/ID ./allbombs/CS201408/U201414776
cp ./bombs/bomb201414776/README ./allbombs/CS201408/U201414776
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414777 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414777
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414777
cd ../..
cp ./bombs/bomb201414777/bomb ./allbombs/CS201408/U201414777
cp ./bombs/bomb201414777/bomb.c ./allbombs/CS201408/U201414777
cp ./bombs/bomb201414777/ID ./allbombs/CS201408/U201414777
cp ./bombs/bomb201414777/README ./allbombs/CS201408/U201414777
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414778 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414778
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414778
cd ../..
cp ./bombs/bomb201414778/bomb ./allbombs/CS201408/U201414778
cp ./bombs/bomb201414778/bomb.c ./allbombs/CS201408/U201414778
cp ./bombs/bomb201414778/ID ./allbombs/CS201408/U201414778
cp ./bombs/bomb201414778/README ./allbombs/CS201408/U201414778
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414779 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414779
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414779
cd ../..
cp ./bombs/bomb201414779/bomb ./allbombs/CS201408/U201414779
cp ./bombs/bomb201414779/bomb.c ./allbombs/CS201408/U201414779
cp ./bombs/bomb201414779/ID ./allbombs/CS201408/U201414779
cp ./bombs/bomb201414779/README ./allbombs/CS201408/U201414779
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414780 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414780
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414780
cd ../..
cp ./bombs/bomb201414780/bomb ./allbombs/CS201408/U201414780
cp ./bombs/bomb201414780/bomb.c ./allbombs/CS201408/U201414780
cp ./bombs/bomb201414780/ID ./allbombs/CS201408/U201414780
cp ./bombs/bomb201414780/README ./allbombs/CS201408/U201414780
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414781 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414781
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414781
cd ../..
cp ./bombs/bomb201414781/bomb ./allbombs/CS201408/U201414781
cp ./bombs/bomb201414781/bomb.c ./allbombs/CS201408/U201414781
cp ./bombs/bomb201414781/ID ./allbombs/CS201408/U201414781
cp ./bombs/bomb201414781/README ./allbombs/CS201408/U201414781
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414782 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414782
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414782
cd ../..
cp ./bombs/bomb201414782/bomb ./allbombs/CS201408/U201414782
cp ./bombs/bomb201414782/bomb.c ./allbombs/CS201408/U201414782
cp ./bombs/bomb201414782/ID ./allbombs/CS201408/U201414782
cp ./bombs/bomb201414782/README ./allbombs/CS201408/U201414782
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414783 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414783
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414783
cd ../..
cp ./bombs/bomb201414783/bomb ./allbombs/CS201408/U201414783
cp ./bombs/bomb201414783/bomb.c ./allbombs/CS201408/U201414783
cp ./bombs/bomb201414783/ID ./allbombs/CS201408/U201414783
cp ./bombs/bomb201414783/README ./allbombs/CS201408/U201414783
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414784 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414784
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414784
cd ../..
cp ./bombs/bomb201414784/bomb ./allbombs/CS201408/U201414784
cp ./bombs/bomb201414784/bomb.c ./allbombs/CS201408/U201414784
cp ./bombs/bomb201414784/ID ./allbombs/CS201408/U201414784
cp ./bombs/bomb201414784/README ./allbombs/CS201408/U201414784
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414785 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414785
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414785
cd ../..
cp ./bombs/bomb201414785/bomb ./allbombs/CS201408/U201414785
cp ./bombs/bomb201414785/bomb.c ./allbombs/CS201408/U201414785
cp ./bombs/bomb201414785/ID ./allbombs/CS201408/U201414785
cp ./bombs/bomb201414785/README ./allbombs/CS201408/U201414785
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414786 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414786
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414786
cd ../..
cp ./bombs/bomb201414786/bomb ./allbombs/CS201408/U201414786
cp ./bombs/bomb201414786/bomb.c ./allbombs/CS201408/U201414786
cp ./bombs/bomb201414786/ID ./allbombs/CS201408/U201414786
cp ./bombs/bomb201414786/README ./allbombs/CS201408/U201414786
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414787 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414787
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414787
cd ../..
cp ./bombs/bomb201414787/bomb ./allbombs/CS201408/U201414787
cp ./bombs/bomb201414787/bomb.c ./allbombs/CS201408/U201414787
cp ./bombs/bomb201414787/ID ./allbombs/CS201408/U201414787
cp ./bombs/bomb201414787/README ./allbombs/CS201408/U201414787
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414788 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414788
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414788
cd ../..
cp ./bombs/bomb201414788/bomb ./allbombs/CS201408/U201414788
cp ./bombs/bomb201414788/bomb.c ./allbombs/CS201408/U201414788
cp ./bombs/bomb201414788/ID ./allbombs/CS201408/U201414788
cp ./bombs/bomb201414788/README ./allbombs/CS201408/U201414788
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414789 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414789
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414789
cd ../..
cp ./bombs/bomb201414789/bomb ./allbombs/CS201408/U201414789
cp ./bombs/bomb201414789/bomb.c ./allbombs/CS201408/U201414789
cp ./bombs/bomb201414789/ID ./allbombs/CS201408/U201414789
cp ./bombs/bomb201414789/README ./allbombs/CS201408/U201414789
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414790 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414790
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414790
cd ../..
cp ./bombs/bomb201414790/bomb ./allbombs/CS201408/U201414790
cp ./bombs/bomb201414790/bomb.c ./allbombs/CS201408/U201414790
cp ./bombs/bomb201414790/ID ./allbombs/CS201408/U201414790
cp ./bombs/bomb201414790/README ./allbombs/CS201408/U201414790
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414792 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414792
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414792
cd ../..
cp ./bombs/bomb201414792/bomb ./allbombs/CS201408/U201414792
cp ./bombs/bomb201414792/bomb.c ./allbombs/CS201408/U201414792
cp ./bombs/bomb201414792/ID ./allbombs/CS201408/U201414792
cp ./bombs/bomb201414792/README ./allbombs/CS201408/U201414792
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414793 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414793
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414793
cd ../..
cp ./bombs/bomb201414793/bomb ./allbombs/CS201408/U201414793
cp ./bombs/bomb201414793/bomb.c ./allbombs/CS201408/U201414793
cp ./bombs/bomb201414793/ID ./allbombs/CS201408/U201414793
cp ./bombs/bomb201414793/README ./allbombs/CS201408/U201414793
cd allbombs
zip -r CS201408.zip CS201408
cd ..

./makebomb.pl -i 201414794 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414794
cd allbombs
mkdir CS201408
cd CS201408
mkdir U201414794
cd ../..
cp ./bombs/bomb201414794/bomb ./allbombs/CS201408/U201414794
cp ./bombs/bomb201414794/bomb.c ./allbombs/CS201408/U201414794
cp ./bombs/bomb201414794/ID ./allbombs/CS201408/U201414794
cp ./bombs/bomb201414794/README ./allbombs/CS201408/U201414794
cd allbombs
zip -r CS201408.zip CS201408
cd ..

