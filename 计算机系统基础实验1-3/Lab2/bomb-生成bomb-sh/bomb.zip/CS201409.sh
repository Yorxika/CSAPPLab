./makebomb.pl -i 201313618 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201313618
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201313618
cd ../..
cp ./bombs/bomb201313618/bomb ./allbombs/CS201409/U201313618
cp ./bombs/bomb201313618/bomb.c ./allbombs/CS201409/U201313618
cp ./bombs/bomb201313618/ID ./allbombs/CS201409/U201313618
cp ./bombs/bomb201313618/README ./allbombs/CS201409/U201313618
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414795 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414795
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414795
cd ../..
cp ./bombs/bomb201414795/bomb ./allbombs/CS201409/U201414795
cp ./bombs/bomb201414795/bomb.c ./allbombs/CS201409/U201414795
cp ./bombs/bomb201414795/ID ./allbombs/CS201409/U201414795
cp ./bombs/bomb201414795/README ./allbombs/CS201409/U201414795
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414796 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414796
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414796
cd ../..
cp ./bombs/bomb201414796/bomb ./allbombs/CS201409/U201414796
cp ./bombs/bomb201414796/bomb.c ./allbombs/CS201409/U201414796
cp ./bombs/bomb201414796/ID ./allbombs/CS201409/U201414796
cp ./bombs/bomb201414796/README ./allbombs/CS201409/U201414796
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414797 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414797
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414797
cd ../..
cp ./bombs/bomb201414797/bomb ./allbombs/CS201409/U201414797
cp ./bombs/bomb201414797/bomb.c ./allbombs/CS201409/U201414797
cp ./bombs/bomb201414797/ID ./allbombs/CS201409/U201414797
cp ./bombs/bomb201414797/README ./allbombs/CS201409/U201414797
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414798 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414798
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414798
cd ../..
cp ./bombs/bomb201414798/bomb ./allbombs/CS201409/U201414798
cp ./bombs/bomb201414798/bomb.c ./allbombs/CS201409/U201414798
cp ./bombs/bomb201414798/ID ./allbombs/CS201409/U201414798
cp ./bombs/bomb201414798/README ./allbombs/CS201409/U201414798
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414800 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414800
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414800
cd ../..
cp ./bombs/bomb201414800/bomb ./allbombs/CS201409/U201414800
cp ./bombs/bomb201414800/bomb.c ./allbombs/CS201409/U201414800
cp ./bombs/bomb201414800/ID ./allbombs/CS201409/U201414800
cp ./bombs/bomb201414800/README ./allbombs/CS201409/U201414800
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414801 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414801
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414801
cd ../..
cp ./bombs/bomb201414801/bomb ./allbombs/CS201409/U201414801
cp ./bombs/bomb201414801/bomb.c ./allbombs/CS201409/U201414801
cp ./bombs/bomb201414801/ID ./allbombs/CS201409/U201414801
cp ./bombs/bomb201414801/README ./allbombs/CS201409/U201414801
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414802 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414802
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414802
cd ../..
cp ./bombs/bomb201414802/bomb ./allbombs/CS201409/U201414802
cp ./bombs/bomb201414802/bomb.c ./allbombs/CS201409/U201414802
cp ./bombs/bomb201414802/ID ./allbombs/CS201409/U201414802
cp ./bombs/bomb201414802/README ./allbombs/CS201409/U201414802
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414803 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414803
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414803
cd ../..
cp ./bombs/bomb201414803/bomb ./allbombs/CS201409/U201414803
cp ./bombs/bomb201414803/bomb.c ./allbombs/CS201409/U201414803
cp ./bombs/bomb201414803/ID ./allbombs/CS201409/U201414803
cp ./bombs/bomb201414803/README ./allbombs/CS201409/U201414803
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414804 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414804
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414804
cd ../..
cp ./bombs/bomb201414804/bomb ./allbombs/CS201409/U201414804
cp ./bombs/bomb201414804/bomb.c ./allbombs/CS201409/U201414804
cp ./bombs/bomb201414804/ID ./allbombs/CS201409/U201414804
cp ./bombs/bomb201414804/README ./allbombs/CS201409/U201414804
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414805 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414805
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414805
cd ../..
cp ./bombs/bomb201414805/bomb ./allbombs/CS201409/U201414805
cp ./bombs/bomb201414805/bomb.c ./allbombs/CS201409/U201414805
cp ./bombs/bomb201414805/ID ./allbombs/CS201409/U201414805
cp ./bombs/bomb201414805/README ./allbombs/CS201409/U201414805
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414806 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414806
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414806
cd ../..
cp ./bombs/bomb201414806/bomb ./allbombs/CS201409/U201414806
cp ./bombs/bomb201414806/bomb.c ./allbombs/CS201409/U201414806
cp ./bombs/bomb201414806/ID ./allbombs/CS201409/U201414806
cp ./bombs/bomb201414806/README ./allbombs/CS201409/U201414806
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414808 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414808
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414808
cd ../..
cp ./bombs/bomb201414808/bomb ./allbombs/CS201409/U201414808
cp ./bombs/bomb201414808/bomb.c ./allbombs/CS201409/U201414808
cp ./bombs/bomb201414808/ID ./allbombs/CS201409/U201414808
cp ./bombs/bomb201414808/README ./allbombs/CS201409/U201414808
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414809 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414809
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414809
cd ../..
cp ./bombs/bomb201414809/bomb ./allbombs/CS201409/U201414809
cp ./bombs/bomb201414809/bomb.c ./allbombs/CS201409/U201414809
cp ./bombs/bomb201414809/ID ./allbombs/CS201409/U201414809
cp ./bombs/bomb201414809/README ./allbombs/CS201409/U201414809
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414810 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414810
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414810
cd ../..
cp ./bombs/bomb201414810/bomb ./allbombs/CS201409/U201414810
cp ./bombs/bomb201414810/bomb.c ./allbombs/CS201409/U201414810
cp ./bombs/bomb201414810/ID ./allbombs/CS201409/U201414810
cp ./bombs/bomb201414810/README ./allbombs/CS201409/U201414810
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414812 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414812
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414812
cd ../..
cp ./bombs/bomb201414812/bomb ./allbombs/CS201409/U201414812
cp ./bombs/bomb201414812/bomb.c ./allbombs/CS201409/U201414812
cp ./bombs/bomb201414812/ID ./allbombs/CS201409/U201414812
cp ./bombs/bomb201414812/README ./allbombs/CS201409/U201414812
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414813 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414813
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414813
cd ../..
cp ./bombs/bomb201414813/bomb ./allbombs/CS201409/U201414813
cp ./bombs/bomb201414813/bomb.c ./allbombs/CS201409/U201414813
cp ./bombs/bomb201414813/ID ./allbombs/CS201409/U201414813
cp ./bombs/bomb201414813/README ./allbombs/CS201409/U201414813
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414814 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414814
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414814
cd ../..
cp ./bombs/bomb201414814/bomb ./allbombs/CS201409/U201414814
cp ./bombs/bomb201414814/bomb.c ./allbombs/CS201409/U201414814
cp ./bombs/bomb201414814/ID ./allbombs/CS201409/U201414814
cp ./bombs/bomb201414814/README ./allbombs/CS201409/U201414814
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414815 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414815
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414815
cd ../..
cp ./bombs/bomb201414815/bomb ./allbombs/CS201409/U201414815
cp ./bombs/bomb201414815/bomb.c ./allbombs/CS201409/U201414815
cp ./bombs/bomb201414815/ID ./allbombs/CS201409/U201414815
cp ./bombs/bomb201414815/README ./allbombs/CS201409/U201414815
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414816 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414816
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414816
cd ../..
cp ./bombs/bomb201414816/bomb ./allbombs/CS201409/U201414816
cp ./bombs/bomb201414816/bomb.c ./allbombs/CS201409/U201414816
cp ./bombs/bomb201414816/ID ./allbombs/CS201409/U201414816
cp ./bombs/bomb201414816/README ./allbombs/CS201409/U201414816
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414817 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414817
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414817
cd ../..
cp ./bombs/bomb201414817/bomb ./allbombs/CS201409/U201414817
cp ./bombs/bomb201414817/bomb.c ./allbombs/CS201409/U201414817
cp ./bombs/bomb201414817/ID ./allbombs/CS201409/U201414817
cp ./bombs/bomb201414817/README ./allbombs/CS201409/U201414817
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414818 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414818
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414818
cd ../..
cp ./bombs/bomb201414818/bomb ./allbombs/CS201409/U201414818
cp ./bombs/bomb201414818/bomb.c ./allbombs/CS201409/U201414818
cp ./bombs/bomb201414818/ID ./allbombs/CS201409/U201414818
cp ./bombs/bomb201414818/README ./allbombs/CS201409/U201414818
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414819 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414819
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414819
cd ../..
cp ./bombs/bomb201414819/bomb ./allbombs/CS201409/U201414819
cp ./bombs/bomb201414819/bomb.c ./allbombs/CS201409/U201414819
cp ./bombs/bomb201414819/ID ./allbombs/CS201409/U201414819
cp ./bombs/bomb201414819/README ./allbombs/CS201409/U201414819
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414820 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414820
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414820
cd ../..
cp ./bombs/bomb201414820/bomb ./allbombs/CS201409/U201414820
cp ./bombs/bomb201414820/bomb.c ./allbombs/CS201409/U201414820
cp ./bombs/bomb201414820/ID ./allbombs/CS201409/U201414820
cp ./bombs/bomb201414820/README ./allbombs/CS201409/U201414820
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414821 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414821
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414821
cd ../..
cp ./bombs/bomb201414821/bomb ./allbombs/CS201409/U201414821
cp ./bombs/bomb201414821/bomb.c ./allbombs/CS201409/U201414821
cp ./bombs/bomb201414821/ID ./allbombs/CS201409/U201414821
cp ./bombs/bomb201414821/README ./allbombs/CS201409/U201414821
cd allbombs
zip -r CS201409.zip CS201409
cd ..

./makebomb.pl -i 201414822 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414822
cd allbombs
mkdir CS201409
cd CS201409
mkdir U201414822
cd ../..
cp ./bombs/bomb201414822/bomb ./allbombs/CS201409/U201414822
cp ./bombs/bomb201414822/bomb.c ./allbombs/CS201409/U201414822
cp ./bombs/bomb201414822/ID ./allbombs/CS201409/U201414822
cp ./bombs/bomb201414822/README ./allbombs/CS201409/U201414822
cd allbombs
zip -r CS201409.zip CS201409
cd ..

